let isRunning = false;
let foundCount = 0;
let snipedCount = 0;
let abortController = null;
let currentIndex = 0;

const DISCORD_API_BASE = 'https://discord.com/api/v9';
const CHECK_ENDPOINT = '/users/@me/pomelo-attempt';
const CLAIM_ENDPOINT = '/users/@me/pomelo';

function getTimeStr() {
    return new Date().toLocaleTimeString('ja-JP', { hour12: false });
}

function addLog(message, type = 'system') {
    const logBox = document.getElementById('logBox');
    if (!logBox) return;

    const entry = document.createElement('div');
    entry.className = `log-entry ${type}`;
    entry.innerHTML = `<span class="log-time">[${getTimeStr()}]</span> ${message}`;
    logBox.appendChild(entry);
    logBox.scrollTop = logBox.scrollHeight;
}

function clearLogs() {
    const logBox = document.getElementById('logBox');
    if (logBox) {
        logBox.innerHTML = `<div class="log-entry system"><span class="log-time">[${getTimeStr()}]</span> 🗑️ ログを消去しました</div>`;
    }
}

function buildProxyUrl(proxyBase, targetPath) {
    if (!proxyBase) {
        // プロキシなしの場合は直接（CORSエラーになる可能性が高い）
        return `${DISCORD_API_BASE}${targetPath}`;
    }
    const base = proxyBase.replace(/\/$/, '');
    // CORSプロキシ形式: proxyBase/targetUrl
    return `${base}/${DISCORD_API_BASE}${targetPath}`;
}

function setProxyStatus(status, type = 'waiting') {
    const el = document.getElementById('proxyStatus');
    if (el) {
        el.textContent = status;
        el.className = `status-value ${type}`;
    }
}

function setProgress(current, total) {
    const el = document.getElementById('progress');
    if (el) el.textContent = `${current} / ${total}`;
}

async function checkUsername(token, username, proxyUrl, signal) {
    const url = buildProxyUrl(proxyUrl, CHECK_ENDPOINT);

    const response = await fetch(url, {
        method: 'POST',
        headers: {
            'Authorization': token,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username: username }),
        signal: signal
    });

    return response;
}

async function claimUsername(token, username, proxyUrl, signal) {
    const url = buildProxyUrl(proxyUrl, CLAIM_ENDPOINT);

    addLog(`⚡ 【スナイプ起動】${username} の自動取得を試みています...`, 'sniper');

    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Authorization': token,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username: username }),
            signal: signal
        });

        if (response.ok) {
            addLog(`🎉 成功！！ユーザー名を「${username}」に取得しました！`, 'success');
            snipedCount++;
            const el = document.getElementById('snipedCount');
            if (el) el.textContent = snipedCount;
            return true;
        } else {
            let errText = '';
            try {
                const errData = await response.json();
                errText = errData.message || JSON.stringify(errData);
            } catch (e) {
                errText = await response.text();
            }
            addLog(`❌ スナイプ失敗 (HTTP ${response.status}): ${errText.substring(0, 100)}`, 'danger');
            return false;
        }
    } catch (error) {
        if (error.name === 'AbortError') throw error;
        addLog(`⚠️ スナイプ通信エラー: ${error.message}`, 'danger');
        return false;
    }
}

async function toggleSniper() {
    if (isRunning) {
        // 停止
        if (abortController) {
            abortController.abort();
        }
        isRunning = false;
        updateButtonState(false);
        addLog('🛑 停止ボタンが押されました。処理を中断します...', 'warning');
        return;
    }

    const token = document.getElementById('userToken').value.trim();
    const proxyUrl = document.getElementById('proxyUrl').value.trim();
    const targetsText = document.getElementById('targetList').value.trim();

    if (!token) {
        alert('👤 ユーザートークンを入力してください。');
        return;
    }

    if (!targetsText) {
        alert('📝 ターゲットを入力するか、自動生成してください。');
        return;
    }

    const targets = targetsText.split('\n')
        .map(t => t.trim().toLowerCase())
        .filter(t => t.length > 0);

    if (targets.length === 0) {
        alert('有効なターゲットがありません。');
        return;
    }

    // UI更新
    isRunning = true;
    foundCount = 0;
    snipedCount = 0;
    currentIndex = 0;
    document.getElementById('foundCount').textContent = '0';
    document.getElementById('snipedCount').textContent = '0';

    updateButtonState(true);
    abortController = new AbortController();

    addLog(`📋 探索を開始します。総ターゲット数: ${targets.length.toLocaleString()} 件`, 'info');
    setProxyStatus('接続中...', 'active');

    const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

    for (let i = 0; i < targets.length; i++) {
        if (!isRunning) break;
        currentIndex = i;

        const username = targets[i];
        addLog(`🔍 [${i + 1}/${targets.length}] ${username} をチェック中...`, 'info');
        setProgress(i + 1, targets.length);

        try {
            const response = await checkUsername(token, username, proxyUrl, abortController.signal);

            if (response.status === 200) {
                let data;
                try {
                    data = await response.json();
                } catch (e) {
                    data = {};
                }

                // Discord pomelo-attempt API:
                // taken: true = 使用中（取得不可）
                // taken: false = 利用可能（取得可能）
                // taken: null = 不明

                if (data.taken === false) {
                    addLog(`✨ 【取得可能】を発見: ${username}`, 'success');
                    foundCount++;
                    document.getElementById('foundCount').textContent = foundCount;

                    // 自動スナイプ実行
                    await claimUsername(token, username, proxyUrl, abortController.signal);
                } else if (data.taken === true) {
                    addLog(`😥 取得不可能: ${username}（使用中）`, 'system');
                } else {
                    addLog(`❓ 不明なレスポンス: ${username} → ${JSON.stringify(data)}`, 'warning');
                }
            } else if (response.status === 429) {
                let retryAfter = 5;
                const ra = response.headers.get('retry-after');
                if (ra) retryAfter = parseInt(ra, 10) || 5;

                addLog(`⚠️ レートリミット（429）検知。${retryAfter}秒待機します。`, 'warning');
                setProxyStatus('レートリミット', 'warning');

                // retry-after分待機
                for (let r = retryAfter; r > 0 && isRunning; r--) {
                    setProgress(i + 1, targets.length);
                    await delay(1000);
                }
                setProxyStatus('接続中...', 'active');
                i--; // 同じ文字を再試行
            } else if (response.status === 401) {
                addLog(`❌ 認証エラー (401): トークンが無効です`, 'danger');
                addLog(`💡 トークンを確認して再度お試しください`, 'warning');
                break;
            } else if (response.status === 403) {
                addLog(`❌ アクセス拒否 (403): IPまたはアカウントが制限されています`, 'danger');
                await delay(5000);
                i--;
            } else {
                let errText = '';
                try {
                    errText = await response.text();
                } catch (e) {}
                addLog(`❌ エラー: HTTP ${response.status} (${username}) ${errText.substring(0, 80)}`, 'danger');
            }
        } catch (error) {
            if (error.name === 'AbortError') {
                addLog('🛑 処理を中断しました', 'warning');
                break;
            }
            addLog(`⚠️ 通信エラー: ${error.message}`, 'danger');
            if (error.message.includes('CORS') || error.message.includes('Failed to fetch')) {
                addLog(`💡 CORSエラー: プロキシURLが正しく設定されているか確認してください`, 'warning');
                addLog(`💡 プロキシ例: http://your-proxy.com:8080`, 'warning');
                setProxyStatus('CORSエラー', 'error');
            }
        }

        // 規制防止のため、1リクエストごとに3秒の安全ウェイト
        if (i < targets.length - 1 && isRunning) {
            await delay(3000);
        }
    }

    // 終了処理
    finishSniper();
}

function updateButtonState(running) {
    const btn = document.getElementById('startBtn');
    const text = btn.querySelector('.btn-text');
    const loading = btn.querySelector('.btn-loading');

    if (running) {
        btn.classList.add('running');
        text.style.display = 'none';
        loading.style.display = 'inline';
    } else {
        btn.classList.remove('running');
        text.style.display = 'inline';
        loading.style.display = 'none';
    }
}

function finishSniper() {
    isRunning = false;
    updateButtonState(false);
    setProxyStatus('待機中', 'waiting');
    addLog('🏁 すべてのターゲットの探索が終了しました。', 'info');
    if (snipedCount > 0) {
        addLog(`🎊 スナイプ成功数: ${snipedCount} 件`, 'success');
    }
}

// 初期化
document.addEventListener('DOMContentLoaded', () => {
    addLog('🚀 システム準備完了。トークンとターゲットを設定してください。', 'system');
    addLog('💡 ヒント: CORSプロキシがない場合、ブラウザ拡張機能でCORSを無効化してください。', 'system');
});
