const GENERATOR_CONFIG = {
    '4alpha': {
        length: 4,
        chars: 'abcdefghijklmnopqrstuvwxyz',
        count: 10000
    },
    '4alnum': {
        length: 4,
        chars: 'abcdefghijklmnopqrstuvwxyz0123456789',
        count: 10000
    },
    '4mixed': {
        length: 4,
        chars: 'abcdefghijklmnopqrstuvwxyz0123456789_.',
        count: 10000
    },
    '5alpha': {
        length: 5,
        chars: 'abcdefghijklmnopqrstuvwxyz',
        count: 10000
    },
    '5alnum': {
        length: 5,
        chars: 'abcdefghijklmnopqrstuvwxyz0123456789',
        count: 10000
    },
    '5numeric': {
        length: 5,
        chars: '0123456789',
        count: 10000
    }
};

function generateRandomString(length, chars) {
    let result = '';
    for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
}

function generateUniqueStrings(config) {
    const { length, chars, count } = config;
    const generated = new Set();
    const maxAttempts = count * 5;
    let attempts = 0;

    while (generated.size < count && attempts < maxAttempts) {
        generated.add(generateRandomString(length, chars));
        attempts++;
    }

    return Array.from(generated);
}

function initGenerators() {
    document.querySelectorAll('.gen-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const type = btn.dataset.type;
            const config = GENERATOR_CONFIG[type];

            if (!config) return;

            // グローバルのaddLogを呼び出し
            if (typeof addLog === 'function') {
                addLog(`🎲 ${btn.querySelector('.gen-label').textContent} の自動生成を開始...`, 'info');
            }

            // 非同期で生成（UIをブロックしない）
            setTimeout(() => {
                const results = generateUniqueStrings(config);
                const textarea = document.getElementById('targetList');
                const existing = textarea.value.trim();

                const newContent = existing 
                    ? existing + '\n' + results.join('\n')
                    : results.join('\n');

                textarea.value = newContent;
                updateTargetCount();

                if (typeof addLog === 'function') {
                    addLog(`✅ ${results.length.toLocaleString()} 個のIDを生成しました`, 'success');
                }
            }, 50);
        });
    });
}

function clearTargets() {
    document.getElementById('targetList').value = '';
    updateTargetCount();
    if (typeof addLog === 'function') {
        addLog('🗑️ ターゲットリストをクリアしました', 'info');
    }
}

function removeDuplicates() {
    const textarea = document.getElementById('targetList');
    const lines = textarea.value.split('\n').map(l => l.trim()).filter(l => l);
    const unique = [...new Set(lines)];
    textarea.value = unique.join('\n');
    updateTargetCount();
    const removed = lines.length - unique.length;
    if (typeof addLog === 'function') {
        addLog(`✨ ${removed} 件の重複を削除しました（残り: ${unique.length} 件）`, 'info');
    }
}

function updateTargetCount() {
    const textarea = document.getElementById('targetList');
    const lines = textarea.value.trim().split('\n').filter(l => l.trim());
    const el = document.getElementById('targetCount');
    if (el) el.textContent = `${lines.length.toLocaleString()} 件`;
}

document.addEventListener('DOMContentLoaded', () => {
    initGenerators();
    const textarea = document.getElementById('targetList');
    if (textarea) {
        textarea.addEventListener('input', updateTargetCount);
    }
});
